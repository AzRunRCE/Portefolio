<?php
require 'Controller/Router.php';
$router = new Router();
$router->routerRequest();
?>