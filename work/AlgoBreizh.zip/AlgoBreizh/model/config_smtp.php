<?php
ini_set('SMTP','smtp.celeste.fr'); //FAI correspondant
ini_set('sendmail_from', 'client@algobreizh.fr');
?>