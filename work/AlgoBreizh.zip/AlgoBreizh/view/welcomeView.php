<?php $this->title = "Accueil"; ?>

<div class="container">
  <div class="row">
	<h3>Projets Algo<b>Breizh</b></h3>
	<p><a color="00AA00" href="~an.my">My AN NGOC</a></p>
	<p><a href="~d.samson">Denis SAMSON</a></p>
	<p><a href="~j.cadieu">Jonas CADIEU</a></p>
	<p><a href="~s.gamarde">Sebastien GAMARDE</a></p>
	<p><a href="~s.plaisier">Sylvain PLAISIER</a></p>
	<p><a href="~y.bouchard">Yoann BOUCHARD</a></p>
	<h4><a href="Certificats.zip">Certificats</a></h4>
  </div>
</div>