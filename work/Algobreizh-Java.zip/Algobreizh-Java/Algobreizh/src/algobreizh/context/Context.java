/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algobreizh.context;

import algobreizh.Models.Salesman;


/**
 *
 * @author quentinmartinez
 */
public class Context {
    public  static Salesman currUser = null;

}
